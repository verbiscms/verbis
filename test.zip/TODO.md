# To Do

## Store
- Posts
- Options
- Forms

# Public isnt working for cannonical etc.

## Strings trim suffix in builder

```go
returnString := strings.TrimSuffix(s.string, " ")
```