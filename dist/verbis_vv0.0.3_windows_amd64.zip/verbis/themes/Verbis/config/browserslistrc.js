//Browsers that we support

module.exports = {
	overrideBrowserslist: ["last 2 versions", "Chrome >= 35", "Firefox >= 31", "not ie 10", "not ie_mob 10", "Safari >= 9"]
};
